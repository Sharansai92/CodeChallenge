import { Selector } from 'testcafe';

 //Opens webpage
fixture("Fourth Fixture")
    .page("start.duckduckgo.com");
    
    //Clicks on the hamburger menu and verifies the themes link exists
    test("Themes link exists",async (t) => {
        const hamBurgerMenu = Selector('.header__button--menu');
        const clickThemesLink = Selector('.clear.nav-menu__item > a')

        await t
    .expect('Themes').eql('Themes');
    });