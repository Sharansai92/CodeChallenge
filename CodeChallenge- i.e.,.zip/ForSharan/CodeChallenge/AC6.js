import { Selector } from 'testcafe';



fixture("Sixth  Fixture")
    .page("start.duckduckgo.com");

test("10 suggestions in the dropdown", async (t) => {

    const searchBox = Selector('#search_form_input_homepage');
    const clickOnSearchIcon = Selector('input#search_button_homepage')
    const serchResultsCount = Selector('.results--main .js-results').count;
    await t
        .typeText(searchBox, 'Back to the future ')
        .click(clickOnSearchIcon)
        .expect(serchResultsCount).eql(8);
});
test("10 suggestions in the dropdown", async (t) => {

    const searchBox = Selector('#search_form_input_homepage');
    const clickOnSearchIcon = Selector('input#search_button_homepage')
    const serchResultsCount = Selector('.results--main .js-results').count;
    await t
        .typeText(searchBox, 'BMX Bandits')
        .click(clickOnSearchIcon)
        .expect(serchResultsCount).eql(8);
});
test("10 suggestions in the dropdown", async (t) => {
    const searchBox = Selector('#search_form_input_homepage');
    const clickOnSearchIcon = Selector('input#search_button_homepage')
    const serchResultsCount = Selector('.results--main .js-results').count;
    await t
        .typeText(searchBox, 'Rocky IV')
        .click(clickOnSearchIcon)
        .expect(serchResultsCount).eql(8);
});
test("10 suggestions in the dropdown", async (t) => {

    const searchBox = Selector('#search_form_input_homepage');
    const clickOnSearchIcon = Selector('input#search_button_homepage')
    const serchResultsCount = Selector('.results--main .js-results').count;
    await t
        .typeText(searchBox, 'Short Circuit ')
        .click(clickOnSearchIcon)
        .expect(serchResultsCount).eql(8);
});
test("10 suggestions in the dropdown", async (t) => {

    const searchBox = Selector('#search_form_input_homepage');
    const clickOnSearchIcon = Selector('input#search_button_homepage')
    const serchResultsCount = Selector('.results--main .js-results').count;
    await t
        .typeText(searchBox, 'The Termintor ')
        .click(clickOnSearchIcon)
        .expect(serchResultsCount).eql(8);
});
test("10 suggestions in the dropdown", async (t) => {

    const searchBox = Selector('#search_form_input_homepage');
    const clickOnSearchIcon = Selector('input#search_button_homepage');
    const serchResultsCount = Selector('.results--main #links').count;


    await t
        .typeText(searchBox, 'Ferris Buellers day off')
        .click(clickOnSearchIcon)
        .expect(serchResultsCount).eql(8);
});