import { Selector } from 'testcafe';

 //Opens webpage
fixture("First Fixture")
    .page("start.duckduckgo.com"); 
    
    test("Duck logo exists", async (t) => {

//verifies if the logo exists on the page
  const duckLogoExists = Selector('.logo_homepage').exists;
  await t.expect(duckLogoExists).ok();      
    });
    