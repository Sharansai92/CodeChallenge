import { Selector } from 'testcafe';

 //Opens webpage
fixture("Second Fixture")
    .page("start.duckduckgo.com");
    
    test("10 suggestions in the dropdown",async (t) => {
        const searchBox = Selector('#search_form_input_homepage');
        const suggestionsCount = Selector('.acp').count;

        //Inputs the search item and verfies against the search field for the number of results
        await t
        .typeText(searchBox,'super')
        .expect(suggestionsCount).eql(8);
        
    });
