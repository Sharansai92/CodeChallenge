import { Selector } from 'testcafe';

 //Opens webpage
fixture("Seventh Fixture")
    .page("https://start.duckduckgo.com/traffic");

    test("traffic page", async (t) => {

        const click2018TrafficSection = Selector('div:nth-of-type(6) > .collapsed.traffic__year');

        //Clicks on the 2018 traffic section
        await t 
        .click(click2018TrafficSection)
        .expect(click2018TrafficSection.value).contains('December November October September August July June May April March February Janury');

    });