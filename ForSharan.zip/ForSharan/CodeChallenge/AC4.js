import { Selector } from 'testcafe';


fixture("Fourth Fixture")
    .page("start.duckduckgo.com");
    
    test("Themes link exists",async (t) => {
        const hamBurgerMenu = Selector('.header__button--menu');
        const clickThemesLink = Selector('.clear.nav-menu__item > a')

        await t
    .expect('Themes').eql('Themes');
    });