import { Selector } from 'testcafe';


fixture("Third Fixture")
    .page("start.duckduckgo.com");
    
    test("10 suggestions in the dropdown",async (t) => {
        const searchBox = Selector('#search_form_input_homepage');
        const firstResult = Selector('.acp-wrap.js-acp-wrap > div:nth-of-type(1)')

        await t
        .typeText(searchBox,'supercalafraglistic')
    .expect(firstResult.value).eql('supercalafragalisticexpialadoshus');
    });