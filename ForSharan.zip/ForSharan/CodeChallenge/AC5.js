import { Selector } from 'testcafe';


fixture("Fifth fixture")
    .page("start.duckduckgo.com");
    
    test("Background colour has changed to dark",async (t) => {
        const hamBurgerMenu = Selector('.header__button--menu');
        const ThemesLink = Selector('.clear.nav-menu__item > a')
        const DarkTheme = Selector('div:nth-of-type(4) > .set-theme > .set-theme__color-3')
        await t
    .click(hamBurgerMenu)
    .click(ThemesLink)
    .click(DarkTheme)
    });