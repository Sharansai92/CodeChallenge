import { Selector } from 'testcafe';


fixture("Second Fixture")
    .page("start.duckduckgo.com");
    
    test("10 suggestions in the dropdown",async (t) => {
        const searchBox = Selector('#search_form_input_homepage');
        const suggestionsCount = Selector('.acp').count;

        await t
        .typeText(searchBox,'super')
        .expect(suggestionsCount).eql(8);
        
    });
