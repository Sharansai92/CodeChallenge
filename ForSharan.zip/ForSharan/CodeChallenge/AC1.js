import { Selector } from 'testcafe';

fixture("First Fixture")
    .page("start.duckduckgo.com");
    
    test("Duck logo exists", async (t) => {
  const duckLogoExists = Selector('.logo_homepage').exists;
  await t.expect(duckLogoExists).ok();      
    });
    